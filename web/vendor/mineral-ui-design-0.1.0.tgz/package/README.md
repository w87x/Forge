# Mineral

A reusable design system extracted from Prism: dark mineral palettes, procedural textures, CSS foundations, and Svelte 5 components. This is an independent package; Prism is not required and is not currently wired to it.

## Try the gallery

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. The theme and texture selectors let you explore the system.

## Use in another project

Install locally from the consuming project (or publish this package to your own registry):

```sh
npm install /Users/danil/Development/mineral @fontsource/jetbrains-mono
```

For a Svelte 5 app with a Svelte-aware bundler, import the styles once in your app entry and use components:

```js
import '@fontsource/jetbrains-mono/400.css';
import '@fontsource/jetbrains-mono/500.css';
import '@fontsource/jetbrains-mono/700.css';
import '@mineral-ui/design/styles.css';
```

```svelte
<script>
  import { Button, Panel, Input } from '@mineral-ui/design';
  let name = $state('');
</script>

<Panel title="Profile">
  <Input bind:value={name} placeholder="Name" />
  <Button variant="accent" onclick={() => console.log(name)}>Save</Button>
</Panel>
```

The package provides source Svelte components and requires Svelte 5 as a peer dependency. Components include buttons, fields, selections, panels, dialogs, badges, charts, tabs and more; see `src/index.js` for the full list and component files for props. Use visible labels for inputs and switches. The existing modal provides Escape and backdrop dismissal but does not yet trap or restore focus; add appropriate focus management for your application.

### CSS without Svelte

`@mineral-ui/design/tokens.css` defines the default CSS custom properties without styling elements. `@mineral-ui/design/base.css` provides global typography, background, common classes (`row`, `chip`, `ibtn`, `t`, etc.), scrollbars and fullscreen styles. `@mineral-ui/design/themes.css` provides theme overrides and page backgrounds. `styles.css` imports all three in that order. Base and themes deliberately style `body`, elements, and short utility class names globally; opt into them only if those effects fit your project. Individual Svelte component styles live in their components, not in the CSS-only bundle.

The default font stack uses JetBrains Mono with monospace fallbacks. The optional font imports above use the separately installed `@fontsource/jetbrains-mono` package. Base CSS includes the Font Awesome solid font for the `.fa` class and resolves it through a modern bundler.

### Themes and textures

The default is Emerald; additional themes are Tanzanite, Cobaltite, Amber, Amethyst, Opal, Aquamarine, Moonstone and Obsidian. Set `data-theme` on `<html>` for CSS-only themes, or use the browser helpers:

```js
import { THEMES, TEXTURES, currentTheme, currentTexture, applyTheme, applyTexture } from '@mineral-ui/design/themes';
applyTheme(currentTheme(), false);
applyTexture(currentTexture(), false);
// Later: applyTheme('amber'); applyTexture('grid');
```

Call helpers in the browser before mounting to avoid a theme flash. They persist choices under `mineral.theme` and `mineral.texture` by default; pass `false` as the second argument to skip saving. `applyTheme` dispatches a `mineral-theme` event and updates an existing `meta[name="theme-color"]`. Textures (`mineral`, `grid`, `none`) are generated in the browser and used by the page background. The helpers access browser APIs, so do not call them during server rendering. Theme CSS alone works without JavaScript, but procedural textures require the helpers.

Panel persistence is opt-in through its `id` prop and uses `mineral.panel.<id>.*` in local storage. Choose unique IDs within your application. Prism-specific branding and application data were intentionally excluded.

## Development

`npm run check` compiles every component; `npm run build` builds the gallery. The design and components originated in Prism and retain its MIT license. These are an initial extraction, not yet a versioned public release; APIs may change.
